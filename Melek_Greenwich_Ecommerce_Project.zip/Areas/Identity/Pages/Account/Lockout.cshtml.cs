﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SecureWebApp.Areas.Identity.Pages.Account
{
    [AllowAnonymous]
    public class LockoutModel : PageModel
    {

        public void OnGet()
        {
            if (TempData.TryGetValue("UnlockEmailMsg", out var data))
            {
            }
        }
    }
}
