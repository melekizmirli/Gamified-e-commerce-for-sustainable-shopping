﻿namespace Melek_Greenwich_Ecommerce_Project.Models
{
    public enum EnumCategories
    {
        Recycled = 1,
        Vegan = 2,
        Used = 3,
        Ecologic = 4
    }
    public class Categories
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
