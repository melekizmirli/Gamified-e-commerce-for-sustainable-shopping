﻿namespace Melek_Greenwich_Ecommerce_Project.Models
{
    public class BasketViewModel
    {
        public string VoucherCode { get; set; }
        public List<BasketItemViewModel> Basket { get; set; }
        public decimal Discount { get; set; }
        public decimal Total { get;  set; }
    }
}
