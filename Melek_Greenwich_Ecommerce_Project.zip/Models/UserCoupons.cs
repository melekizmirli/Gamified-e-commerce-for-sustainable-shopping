﻿namespace Melek_Greenwich_Ecommerce_Project.Models
{
    public class UserCoupons
    {
        public int Id { get; set; }
        public string UserEmail { get; set; }
        public int VoucherCodeId { get; set; }
        public bool IsUsed { get; set; }
    }
}
