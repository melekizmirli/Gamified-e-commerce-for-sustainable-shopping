﻿namespace Melek_Greenwich_Ecommerce_Project.Models
{
    public class BasketItemViewModel
    {
        public int Id { get; set; }
        public int basketId { get; set; }
        public int productId { get; set; }
        public string name { get; set; }
        public decimal price { get; set; }
        public int quantity { get; set; }
        public string categoryname { get; set; }
    }
}
