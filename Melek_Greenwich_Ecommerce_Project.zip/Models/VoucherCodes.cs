﻿namespace Melek_Greenwich_Ecommerce_Project.Models
{
    public class VoucherCodes
    {
        public int Id { get; set; } 
        
        public string Name { get; set; }

        public int DiscountRate { get; set; }
    }
}
