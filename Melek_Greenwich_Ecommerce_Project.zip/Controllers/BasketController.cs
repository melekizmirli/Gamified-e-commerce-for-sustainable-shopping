﻿using Melek_Greenwich_Ecommerce_Project.Data;
using Melek_Greenwich_Ecommerce_Project.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace Melek_Greenwich_Ecommerce_Project.Controllers
{
    [Authorize]
    public class BasketController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _dbContext;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly HttpContext _httpContext;

        public BasketController(ILogger<HomeController> logger, ApplicationDbContext dbContext, IHttpContextAccessor httpContextAccessor)
        {
            _logger = logger;
            this._dbContext = dbContext;
            this._httpContextAccessor = httpContextAccessor;
            this._httpContext = httpContextAccessor.HttpContext;
        }

        [HttpGet]
        public IActionResult Index()
        {
            var list = CalculateBasket();
            var model = new BasketViewModel { Basket = list, Total = list.Sum(x => x.price) };

            return View(model);
        }

        [HttpPost()]
        public IActionResult VoucherCodeApply(string voucherCode)
        {
            var list = CalculateBasket();
            var model = new BasketViewModel { Basket = list, Total = list.Sum(x => x.price), VoucherCode = voucherCode };

            var vcode = _dbContext.VoucherCodes.FirstOrDefault(x => x.Name == voucherCode);
            if (vcode != null)
            {
                model.Discount = model.Total / 100 * vcode.DiscountRate;
                model.Total = model.Total - model.Discount;
            }

            return View("Index", model);
        }
        List<BasketItemViewModel> CalculateBasket()
        {
            var list = (from a in _dbContext.Basket
                        join pd in _dbContext.Products on a.ProductId equals pd.Id
                        join c in _dbContext.Categories on pd.CategoryId equals c.Id
                        where a.CustomerEmail == HttpContext.User.Identity.Name
                        select new BasketItemViewModel
                        {
                            basketId = a.Id,
                            productId = pd.Id,
                            name = pd.Name,
                            price = pd.Price,
                            quantity = a.Quantity,
                            categoryname = c.Name
                        }
                        ).ToList<BasketItemViewModel>();
            return list;
        }
        [HttpPost]
        public async Task<IActionResult> AddBasket(int id)
        {
            Product product = await _dbContext.Products.FirstOrDefaultAsync(p => p.Id == id);

            Basket basket = new Basket
            {

                ProductId = product.Id,
                CustomerEmail = _httpContext.User.Identity.Name,
                Quantity = 1,
                UnitPrice = product.Price
            };

            _dbContext.Basket.Add(basket);
            _dbContext.SaveChanges();

            return RedirectToAction("index");// View("/home/detail", new {id=id});
        }

        [HttpGet]
        public async Task<IActionResult> RemoveItem(int id)
        {
            var item = _dbContext.Basket.FirstOrDefault(x => x.Id == id);
            _dbContext.Basket.Remove(item);
            _dbContext.SaveChanges();

            return RedirectToAction("index");// View("/home/detail", new {id=id});
        }

        [HttpPost]
        public async Task<IActionResult> Pay()
        {
            int level = 0;
            using (var conn = new SqlConnection(_dbContext.Database.GetConnectionString()))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("select top 1 gamelevel from AspNetUsers where UserName='" + HttpContext.User.Identity.Name + "'", conn);
                level = Convert.ToInt32(cmd.ExecuteScalar());
            }

            var items = (from b in _dbContext.Basket
                         join p in _dbContext.Products on b.ProductId equals p.Id
                         join c in _dbContext.Categories on p.CategoryId equals c.Id
                         where b.CustomerEmail == _httpContext.User.Identity.Name
                         select new
                         {
                             basketId = b.Id,
                             productId = p.Id,
                             categoryId = c.Id,
                             categoryName = c.Name
                         }).ToList();
            bool LevelUp = false;
            foreach (var item in items)
            {
                if (level == 1 && item.categoryId == (int)EnumCategories.Recycled)
                {
                    LevelUp = true;
                }
                if (level == 3 && item.categoryId == (int)EnumCategories.Vegan)
                {
                    LevelUp = true;
                }
                var pi = _dbContext.Basket.FirstOrDefault(x => x.ProductId == item.productId);
                _dbContext.Basket.Remove(pi);
                _dbContext.SaveChanges();
            }
           

            string vcode = HttpContext.Request.Form["vcode"];
            if (!string.IsNullOrEmpty(vcode))
            {
                var cup = _dbContext.UserCoupons.FirstOrDefault(x => x.UserEmail == HttpContext.User.Identity.Name);
                if (cup != null)
                {
                    cup.IsUsed = true;
                    _dbContext.UserCoupons.Update(cup);
                    _dbContext.SaveChanges();
                }
            }

            string delivery = HttpContext.Request.Form["delivery"];
            if(level==2 && !string.IsNullOrEmpty(delivery) && (delivery=="2" || delivery=="3"))
            {
                LevelUp = true;
            }

            if (LevelUp)
            {
                level++;
                using (var conn = new SqlConnection(_dbContext.Database.GetConnectionString()))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("update AspNetUsers set gamelevel=" + level.ToString() + "  where  UserName='" + HttpContext.User.Identity.Name + "'", conn);
                    cmd.ExecuteNonQuery();
                }
            }

            return RedirectToAction("index");// View("/home/detail", new {id=id});
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> LandingPage(string email)
        {
            return View("LandingPage", email);
        }

    }
}
