﻿using Melek_Greenwich_Ecommerce_Project.Data;
using Melek_Greenwich_Ecommerce_Project.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace Melek_Greenwich_Ecommerce_Project.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _dbContext;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly HttpContext _httpContext;

        public HomeController(ILogger<HomeController> logger, ApplicationDbContext dbContext, IHttpContextAccessor httpContextAccessor)
        {
            _logger = logger;
            this._dbContext = dbContext;
            this._httpContextAccessor = httpContextAccessor;
            this._httpContext = httpContextAccessor.HttpContext;
        }

        public async Task<IActionResult> Index()
        {
            var list = _dbContext.Products.ToList();
            if (_httpContext.User.Identity.IsAuthenticated)
            {
                //Basket basket = await _dbContext.Baskets.FirstOrDefaultAsync(b => b.CustomerEmail == _httpContext.User.Identity.Name);
                //if (basket != null)
                //{

                //    HttpContext.Session.SetInt32("BasketCount", _dbContext.BasketItems.Count(x => x.BasketId == basket.Id));
                //}
                //else
                //{
                //    HttpContext.Session.SetInt32("BasketCount", 0);
                //}
            }
            return View(list);
        }

        public async Task<IActionResult> Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? _httpContext.TraceIdentifier });
        }

        [HttpGet]
        public async Task<IActionResult> Detail(int id)
        {
            var product = _dbContext.Products.FirstOrDefault(c => c.Id == id);
            ViewBag.Category = _dbContext.Categories.FirstOrDefault(x => x.Id == product.CategoryId).Name;

            return View(product);
        }

        [HttpGet]
        public async Task<IActionResult> OpenModal()
        {
            var list = (from u in _dbContext.UserCoupons
                        join v in _dbContext.VoucherCodes on u.VoucherCodeId equals v.Id
                        where u.UserEmail == HttpContext.User.Identity.Name && u.IsUsed == false
                        select new
                        {
                            name = v.Name,
                        }).ToList();

            ViewBag.Coupons = list;
            var user = _dbContext.Users.FirstOrDefault(x => x.UserName == HttpContext.User.Identity.Name);

            using (var conn = new SqlConnection(_dbContext.Database.GetConnectionString()))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("select top 1 gamelevel from AspNetUsers where UserName='" + HttpContext.User.Identity.Name + "'",conn);
                int data = Convert.ToInt32(cmd.ExecuteScalar());
                ViewBag.level = data;
            }

            return View();
        }

        [HttpGet]
        public async Task<IActionResult> OpenTaskModal(int id)
        {

            var item= _dbContext.GameRules.FirstOrDefault(x => x.Name == id.ToString());
            ViewBag.Level = item.Name;
            ViewBag.Description=item.Description;
            return View();
        }


        


    }
}