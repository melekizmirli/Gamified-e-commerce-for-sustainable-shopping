﻿using Melek_Greenwich_Ecommerce_Project.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure.Internal;

namespace Melek_Greenwich_Ecommerce_Project.Data
{
   public partial class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext()
        {
        }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

       


        public virtual DbSet<Basket> Basket { get; set; }

       

       

        public virtual DbSet<Product> Products { get; set; }
        public virtual DbSet<Categories> Categories { get; set; }

        public virtual DbSet<VoucherCodes> VoucherCodes { get; set; }

        public virtual DbSet<UserCoupons> UserCoupons { get; set; }

        public virtual DbSet<ApplicationUser> ApplicationUser { get; set; }
        public virtual DbSet<GameRules> GameRules { get; set; }


    }

}